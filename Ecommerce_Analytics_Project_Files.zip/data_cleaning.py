import pandas as pd
import numpy as np

def clean_ecommerce_data(input_file='raw_dataset.csv', output_file='clean_dataset.csv'):
    # Load raw dataset
    df = pd.read_csv(input_file)
    print(f"Initial raw record count: {len(df)}")

    # 1. Remove duplicate rows
    df = df.drop_duplicates(subset=['Order_ID'], keep='first').copy()

    # 2. Standardize text casing and strip extra whitespace
    text_cols = ['Category', 'Ship_Mode', 'Region', 'Gender', 'Order_Status']
    for col in text_cols:
        df[col] = df[col].astype(str).str.strip()
        if col == 'Category':
            # Preserve proper title formatting with ampersand
            df[col] = df[col].str.title().str.replace('And', '&')
        else:
            df[col] = df[col].str.title()

    # 3. Handle missing numerical values
    df['Customer_Age'] = df['Customer_Age'].fillna(df['Customer_Age'].median()).astype(int)
    df['Discount'] = df['Discount'].fillna(0.0)

    # Recalculate Sales and Profit where missing or inconsistent
    df['Sales'] = (df['Unit_Price'] * df['Quantity'] * (1 - df['Discount'])).round(2)
    median_margin = (df['Profit'] / df['Sales']).median()
    df['Profit'] = df['Profit'].fillna((df['Sales'] * median_margin).round(2))

    # 4. Validate duration metrics
    df['Total_Fulfillment_Hrs'] = (df['Processing_Time_Hrs'] + df['Shipping_Time_Hrs']).round(2)

    # Save cleaned dataset
    df.to_csv(output_file, index=False)
    print(f"Cleaned record count: {len(df)}")
    print(f"Saved cleaned dataset to {output_file}")

if __name__ == "__main__":
    clean_ecommerce_data()
