import pandas as pd
import json

def build_html_dashboard():
    kpis = pd.read_csv('kpi_summary.csv')
    cat_df = pd.read_csv('category_summary.csv')
    hr_df = pd.read_csv('hourly_summary.csv')
    ship_df = pd.read_csv('shipping_summary.csv')
    out_df = pd.read_csv('outcome_summary.csv')

    kpi_dict = dict(zip(kpis['Metric'], kpis['Value']))

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Global E-Commerce Sales & Customer Analytics Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #f4f7fb; margin: 0; padding: 24px; color: #1e293b; }}
  .header {{ background: #0f2942; color: white; padding: 20px 28px; border-radius: 10px; margin-bottom: 24px; }}
  .header h1 {{ margin: 0 0 6px 0; font-size: 24px; }}
  .header p {{ margin: 0; color: #94a3b8; font-size: 14px; }}
  .kpi-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }}
  .kpi-card {{ background: white; padding: 18px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.06); border-left: 4px solid #0284c7; }}
  .kpi-title {{ font-size: 12px; text-transform: uppercase; color: #64748b; font-weight: 600; }}
  .kpi-val {{ font-size: 26px; font-weight: 700; color: #0f2942; margin-top: 6px; }}
  .charts-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }}
  .chart-box {{ background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.06); }}
  .chart-box h3 {{ margin: 0 0 14px 0; font-size: 16px; color: #0f2942; }}
</style>
</head>
<body>
  <div class="header">
    <h1>Global E-Commerce Sales & Customer Analytics Dashboard</h1>
    <p>SR University Academic Project | Student: M. Sricharan Reddy (2503A53037) | Synthetic Dataset (N = 1,200 Orders)</p>
  </div>
  <div class="kpi-grid">
    <div class="kpi-card"><div class="kpi-title">Total Orders</div><div class="kpi-val">{int(kpi_dict['Total Orders']):,}</div></div>
    <div class="kpi-card"><div class="kpi-title">Total Revenue</div><div class="kpi-val">${kpi_dict['Total Revenue ($)']:,.2f}</div></div>
    <div class="kpi-card"><div class="kpi-title">Total Profit</div><div class="kpi-val">${kpi_dict['Total Profit ($)']:,.2f}</div></div>
    <div class="kpi-card"><div class="kpi-title">Avg Fulfillment Time</div><div class="kpi-val">{kpi_dict['Average Total Fulfillment Time (Hrs)']} hrs</div></div>
  </div>
  <div class="charts-grid">
    <div class="chart-box"><h3>Total Revenue by Product Category ($)</h3><canvas id="catChart"></canvas></div>
    <div class="chart-box"><h3>Hourly Order Volume (00:00 – 23:00)</h3><canvas id="hrChart"></canvas></div>
    <div class="chart-box"><h3>Shipping Mode Distribution</h3><canvas id="shipChart"></canvas></div>
    <div class="chart-box"><h3>Order Fulfillment Outcomes</h3><canvas id="outChart"></canvas></div>
  </div>
<script>
  new Chart(document.getElementById('catChart'), {{
    type: 'bar',
    data: {{ labels: {json.dumps(cat_df['Category'].tolist())}, datasets: [{{ label: 'Revenue ($)', data: {json.dumps(cat_df['Total_Sales'].tolist())}, backgroundColor: '#0284c7' }}] }},
    options: {{ indexAxis: 'y', plugins: {{ legend: {{ display: false }} }} }}
  }});
  new Chart(document.getElementById('hrChart'), {{
    type: 'line',
    data: {{ labels: {json.dumps([f"{h:02d}:00" for h in hr_df['Order_Hour']])}, datasets: [{{ label: 'Orders', data: {json.dumps(hr_df['Order_Count'].tolist())}, borderColor: '#0f2942', fill: true, backgroundColor: 'rgba(2,132,199,0.12)' }}] }}
  }});
  new Chart(document.getElementById('shipChart'), {{
    type: 'doughnut',
    data: {{ labels: {json.dumps(ship_df['Ship_Mode'].tolist())}, datasets: [{{ data: {json.dumps(ship_df['Order_Count'].tolist())}, backgroundColor: ['#0f2942','#0284c7','#38bdf8','#bae6fd'] }}] }}
  }});
  new Chart(document.getElementById('outChart'), {{
    type: 'doughnut',
    data: {{ labels: {json.dumps(out_df['Order_Status'].tolist())}, datasets: [{{ data: {json.dumps(out_df['Order_Count'].tolist())}, backgroundColor: ['#16a34a','#f59e0b','#dc2626'] }}] }}
  }});
</script>
</body>
</html>"""

    with open('Ecommerce_Dashboard.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    print("Generated Ecommerce_Dashboard.html successfully!")

if __name__ == "__main__":
    build_html_dashboard()
