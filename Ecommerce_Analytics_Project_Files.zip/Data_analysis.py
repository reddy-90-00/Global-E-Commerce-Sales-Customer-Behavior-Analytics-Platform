import pandas as pd

def run_analysis(input_file='clean_dataset.csv'):
    df = pd.read_csv(input_file)

    # Overall KPIs
    kpis = pd.DataFrame({
        'Metric': [
            'Total Orders',
            'Total Revenue ($)',
            'Total Profit ($)',
            'Average Order Value ($)',
            'Average Processing Time (Hrs)',
            'Average Shipping Time (Hrs)',
            'Average Total Fulfillment Time (Hrs)'
        ],
        'Value': [
            len(df),
            round(df['Sales'].sum(), 2),
            round(df['Profit'].sum(), 2),
            round(df['Sales'].mean(), 2),
            round(df['Processing_Time_Hrs'].mean(), 2),
            round(df['Shipping_Time_Hrs'].mean(), 2),
            round(df['Total_Fulfillment_Hrs'].mean(), 2)
        ]
    })
    kpis.to_csv('kpi_summary.csv', index=False)

    # Category Summary
    category_summary = df.groupby('Category').agg(
        Order_Count=('Order_ID', 'count'),
        Total_Sales=('Sales', 'sum'),
        Total_Profit=('Profit', 'sum'),
        Avg_Order_Value=('Sales', 'mean'),
        Avg_Processing_Hrs=('Processing_Time_Hrs', 'mean')
    ).round(2).sort_values(by='Total_Sales', ascending=False).reset_index()
    category_summary.to_csv('category_summary.csv', index=False)

    # Hourly Order Pattern
    hourly_summary = df.groupby('Order_Hour').agg(
        Order_Count=('Order_ID', 'count'),
        Total_Sales=('Sales', 'sum')
    ).round(2).reset_index()
    hourly_summary.to_csv('hourly_summary.csv', index=False)

    # Shipping Mode Summary
    ship_summary = df.groupby('Ship_Mode').agg(
        Order_Count=('Order_ID', 'count'),
        Percentage=('Order_ID', lambda x: round(len(x) / len(df) * 100, 2)),
        Avg_Shipping_Hrs=('Shipping_Time_Hrs', 'mean')
    ).round(2).reset_index()
    ship_summary.to_csv('shipping_summary.csv', index=False)

    # Order Outcome Summary
    outcome_summary = df.groupby('Order_Status').agg(
        Order_Count=('Order_ID', 'count'),
        Percentage=('Order_ID', lambda x: round(len(x) / len(df) * 100, 2))
    ).round(2).reset_index()
    outcome_summary.to_csv('outcome_summary.csv', index=False)

    print("Analysis complete! Summary CSV files generated:")
    print(kpis.to_string(index=False))

if __name__ == "__main__":
    run_analysis()
